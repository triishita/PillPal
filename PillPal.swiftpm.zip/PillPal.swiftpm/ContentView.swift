import SwiftUI

struct ContentView: View {
    @State private var showIntro = true
    @State private var medications: [Medication] = []
    @State private var showAddMedication = false

    var body: some View {
        NavigationView {
            VStack {
                if showIntro && medications.isEmpty {
                    IntroView(showIntro: $showIntro)
                } else {
                    List {
                        ForEach(medications) { medication in
                            MedicationRow(medication: medication, markAsTaken: { markMedicationAsTaken(medication) },
                                markAsSkipped: { markMedicationAsSkipped(medication) },
                                deleteReminder: { deleteMedicationByID(medication.id) })
                            .padding(.vertical, 8)
                        }
                    }
                    .navigationTitle("Reminders") // ✅ Ensuring title alignment
                    .toolbar {
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button(action: { showAddMedication = true }) {
                                Image(systemName: "plus")
                                    .font(.system(size: 18))
                                    .fontWeight(.bold)
                                    .foregroundColor(.blue)
                            }
                        }
                        ToolbarItem(placement: .navigationBarLeading) {
                            Button("Export as PDF") {
                                exportToPDF()
                            }
                            .font(.system(size: 18))
                            .fontWeight(.bold)
                            .foregroundColor(.blue)
                        }
                    }
                }
            }
            .sheet(isPresented: $showAddMedication) {
                AddMedicationView(medications: $medications)
            }
        }
    }
  
  private func markMedicationAsTaken(_ medication: Medication) {
      if let index = medications.firstIndex(where: { $0.id == medication.id }) {
          medications[index].status = "Taken"
      }
  }

  private func markMedicationAsSkipped(_ medication: Medication) {
      if let index = medications.firstIndex(where: { $0.id == medication.id }) {
          medications[index].status = "Skipped"
      }
  }
  private func deleteMedicationByID(_ id: UUID) {
      medications.removeAll { $0.id == id }
  }
  private func exportToPDF() {
      let pdfRenderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: 612, height: 792))

      let data = pdfRenderer.pdfData { context in
          context.beginPage()
          let title = "Medication Reminders"
          let titleAttributes: [NSAttributedString.Key: Any] = [
              .font: UIFont.boldSystemFont(ofSize: 24)
          ]
          title.draw(at: CGPoint(x: 20, y: 20), withAttributes: titleAttributes)

          var yOffset = 60
          for medication in medications {
              let text = "\(medication.name) - \(medication.doses) doses at \(medication.timing)"
              text.draw(at: CGPoint(x: 20, y: yOffset), withAttributes: [.font: UIFont.systemFont(ofSize: 18)])
              yOffset += 30
          }
      }

      let tempURL = FileManager.default.temporaryDirectory.appendingPathComponent("Reminders.pdf")
      try? data.write(to: tempURL)

      let activityVC = UIActivityViewController(activityItems: [tempURL], applicationActivities: nil)
      UIApplication.shared.windows.first?.rootViewController?.present(activityVC, animated: true)
  }

}

struct IntroView: View {
    @Binding var showIntro: Bool
    
    var body: some View {
        LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.3), Color.purple.opacity(0.3)]),
                       startPoint: .topLeading,
                       endPoint: .bottomTrailing)
            .edgesIgnoringSafeArea(.all)
            .overlay(
                VStack(spacing: 20) {
                    Text("Welcome to PillPal!")
                        .font(.largeTitle)
                        .bold()
                    Text("Easily track your medications and doses.")
                        .multilineTextAlignment(.center)
                        .padding()
                    Button("Get Started") {
                        showIntro = false
                    }
                    .frame(width: 100, height: 20)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
            )
    }
}

struct Medication: Identifiable {
    let id = UUID()
    let name: String
    let doses: Int
    let timing: String
    let shape: String
    let color: Color
    let times: [Date]
    var status: String = "Pending"
}

struct MedicationRow: View {
    let medication: Medication
    var markAsTaken: () -> Void
    var markAsSkipped: () -> Void
    var deleteReminder: () -> Void

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 5) {
                Text(medication.name)
                    .font(.headline)
                Text("Doses per day: \(medication.doses)")
                    .font(.subheadline)
                Text("Timing: \(medication.timing)")
                    .font(.subheadline)
                Text("Status: \(medication.status)")
                    .font(.caption)
                    .fontWeight(.bold)
                    .foregroundColor(statusColor)
            }
            Spacer()
            VStack(spacing: 8) {
                Button(action: markAsTaken) {
                    Text("Taken")
                        .frame(width: 80, height: 30)
                }
                .buttonStyle(.borderedProminent)
                .tint(.green) // ✅ Taken button is now green

                Button(action: markAsSkipped) {
                    Text("Skipped")
                        .frame(width: 80, height: 30)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red) // ✅ Skipped button is now red
            }
            Button(action: deleteReminder) {
                Image(systemName: "trash")
                    .foregroundColor(.red)
            }
            .padding(.leading, 10)
        }
        .padding(.vertical, 8)
        .swipeActions {  // ✅ Added swipe-to-delete action
            Button(role: .destructive, action: deleteReminder) {
                Label("Delete", systemImage: "trash")
            }
        }
    }

    private var statusColor: Color {
        switch medication.status {
        case "Taken": return .green
        case "Skipped": return .red
        default: return .gray
        }
    }
}


struct AddMedicationView: View {
    @Binding var medications: [Medication]
    @Environment(\.presentationMode) var presentationMode

    @State private var name = ""
    @State private var doses = 1
    @State private var timing = "Before Meal"
    @State private var selectedShape = "Round"
    @State private var selectedColor = Color.white // ✅ Default color set to white
    @State private var timeSelections: [Date] = Array(repeating: Date(), count: 3)
    
    let commonMedications = ["Paracetamol", "Ibuprofen", "Aspirin", "Metformin", "Amoxicillin"]
    
    var filteredMedications: [String] {
        commonMedications.filter { $0.lowercased().contains(name.lowercased()) }
    }

    var body: some View {
        NavigationView {
            VStack {
                // ✅ Top Bar with Save and Cancel Buttons
                HStack {
                    Button("Cancel") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .fontWeight(.bold)
                    .font(.system(size: 18))
                    .foregroundColor(.blue)

                    Spacer()

                    Button("Save") {
                        let newMedication = Medication(
                            name: name,
                            doses: doses,
                            timing: timing,
                            shape: selectedShape,
                            color: selectedColor,
                            times: timeSelections.prefix(doses).map { $0 }
                        )
                        medications.append(newMedication)
                        presentationMode.wrappedValue.dismiss()
                    }
                    .fontWeight(.bold)
                    .font(.system(size: 18))
                    .foregroundColor(.blue)
                  
                }
                .padding()

                // ✅ Title Alignment Matched with "Medications"
                Text("Add Medication")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.leading, 20)

                Form {
                    // Medication Name with Autocomplete
                    Section(header: Text("Medication Name")) {
                        TextField("Enter medication name", text: $name)
                        
                        if !filteredMedications.isEmpty && !name.isEmpty {
                            List(filteredMedications, id: \.self) { suggestion in
                                Text(suggestion)
                                    .onTapGesture {
                                        name = suggestion
                                    }
                            }
                            .frame(maxHeight: 100)
                        }
                    }

                    // Number of Doses
                    Stepper(value: $doses, in: 1...3) {
                        Text("Doses per day: \(doses)")
                    }

                    // Meal Timing Toggle
                    Picker("Timing", selection: $timing) {
                        Text("Before Meal").tag("Before Meal")
                        Text("After Meal").tag("After Meal")
                    }
                    .pickerStyle(SegmentedPickerStyle())

                    // ✅ Shape Selection (Now Blue)
                    Section(header: Text("Shape")) {
                        Picker("Select Shape", selection: $selectedShape) {
                            Text("Round").tag("Round")
                            Text("Oval").tag("Oval")
                            Text("Capsule").tag("Capsule")
                        }
                        .pickerStyle(MenuPickerStyle())
                        .tint(.blue) // ✅ This ensures the selected option appears blue
                    }

                    // Color Selection
                    Section(header: Text("Color")) {
                        HStack {
                            ForEach([Color.white, Color.red, Color.blue, Color.green, Color.orange, Color.purple, Color.brown, Color.yellow], id: \.self) { color in
                                Circle()
                                    .fill(color)
                                    .frame(width: 30, height: 30)
                                    .onTapGesture {
                                        selectedColor = color
                                    }
                                    .overlay(
                                        Circle().stroke(Color.black, lineWidth: selectedColor == color ? 2 : 0)
                                    )
                            }
                        }
                    }

                    // Time Picker Based on Doses
                    Section(header: Text("Set Time for Each Dose")) {
                        ForEach(0..<doses, id: \.self) { index in
                            DatePicker("Dose \(index + 1)", selection: $timeSelections[index], displayedComponents: .hourAndMinute)
                        }
                        .tint(.blue)
                    }
                }
            }
            .navigationBarHidden(true) // ✅ Hides default navbar since we moved buttons to top
        }
    }
}
